/** Reviewed Host half of the trusted-installation fixture Bundle. */
import type { Context } from '@worldline/cordis';
/** Provide observable Host evidence for post-restart verification. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map