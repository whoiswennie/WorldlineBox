/** Package-owned invariant companion for the reviewed fixture Bundle. */
import type { Context } from '@worldline/cordis';
export declare const name = "plugin-center-fixture-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map