/** Reviewed Skill-pack fixture loaded through an ordinary WORLDLINE Bundle. */
import type { Context } from '@worldline/cordis';
export declare const inject: string[];
/** Register one deterministic globally discoverable Skill. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map